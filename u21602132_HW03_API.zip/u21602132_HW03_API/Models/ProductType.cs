﻿namespace Assignment3_Backend.Models
{
    public class ProductType : BaseEntity
    {
        public int ProductTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public ICollection<Product> Products { get; set; }
    }
}
