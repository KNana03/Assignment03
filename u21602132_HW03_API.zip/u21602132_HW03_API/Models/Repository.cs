﻿using Microsoft.EntityFrameworkCore;

namespace Assignment3_Backend.Models
{
    public class Repository : IRepository
    {
        private readonly AppDbContext _appDbContext;

        public Repository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            return await _appDbContext.Products
                .Include(p => p.Brand)
                .Include(p => p.ProductType)
                .ToListAsync();
        }

        public async Task<IEnumerable<Brand>> GetBrandsAsync()
        {
            return await _appDbContext.Brands.ToListAsync();
        }

        public async Task<IEnumerable<ProductType>> GetProductTypesAsync()
        {
            return await _appDbContext.ProductTypes.ToListAsync();
        }

        public async Task<object> GenerateProductReportAsync()
        {
            var productCountsByBrand = await _appDbContext.Products
                .GroupBy(p => p.Brand.Name)
                .Select(g => new { Brand = g.Key, Count = g.Count() })
                .ToListAsync();

            var productCountsByType = await _appDbContext.Products
                .GroupBy(p => p.ProductType.Name)
                .Select(g => new { ProductType = g.Key, Count = g.Count() })
                .ToListAsync();

            var activeProductsReport = await _appDbContext.Products
                .Where(p => p.IsActive)
                .GroupBy(p => new { ProductType = p.ProductType.Name, Brand = p.Brand.Name })
                .Select(g => new
                {
                    ProductType = g.Key.ProductType,
                    Brand = g.Key.Brand,
                    Products = g.ToList()
                })
                .ToListAsync();

            return new
            {
                ProductCountsByBrand = productCountsByBrand,
                ProductCountsByType = productCountsByType,
                ActiveProductsReport = activeProductsReport
            };
        }

        public async Task<bool> DeleteProductAsync(int productId)
        {
            var product = await _appDbContext.Products.FindAsync(productId);
            if (product == null)
            {
                return false;
            }

            _appDbContext.Products.Remove(product);
            return await SaveChangesAsync();
        }

    }
    }
