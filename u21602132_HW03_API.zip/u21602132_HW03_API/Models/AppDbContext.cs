﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Assignment3_Backend.Models
{
    public class AppDbContext:IdentityDbContext<AppUser>
    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Brand> Brands { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Brand>().HasData(
           new Brand { BrandId = 1, Name = "Nike", Description = "Nike brand" },
           new Brand { BrandId = 2, Name = "Adidas", Description = "Adidas brand" },
           new Brand { BrandId = 3, Name = "Puma", Description = "Puma brand" }
       );

            modelBuilder.Entity<ProductType>().HasData(
                new ProductType { ProductTypeId = 1, Name = "Footwear", Description = "Footwear products" },
                new ProductType { ProductTypeId = 2, Name = "Apparel", Description = "Apparel products" },
                new ProductType { ProductTypeId = 3, Name = "Accessories", Description = "Accessories products" }
            );
        }
    }
}
