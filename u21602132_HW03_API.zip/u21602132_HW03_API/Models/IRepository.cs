﻿namespace Assignment3_Backend.Models
{
    public interface IRepository
    {
        void Add<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<IEnumerable<Product>> GetProductsAsync();
        Task<IEnumerable<Brand>> GetBrandsAsync();
        Task<IEnumerable<ProductType>> GetProductTypesAsync();
        Task<object> GenerateProductReportAsync();
        Task<bool> DeleteProductAsync(int productId);
    }
}
