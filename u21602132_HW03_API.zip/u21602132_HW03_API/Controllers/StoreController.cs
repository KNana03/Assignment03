﻿using Assignment3_Backend.Models;
using Assignment3_Backend.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoreController : ControllerBase
    {
        private readonly IRepository _repository;

        public StoreController(IRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("productlisting")]
        public async Task<IActionResult> GetProductListing()
        {
            var products = await _repository.GetProductsAsync();
            return Ok(products);
        }

        [HttpGet("getbrands")]
        public async Task<IActionResult> GetBrands()
        {
            var brands = await _repository.GetBrandsAsync();
            return Ok(brands);
        }

        [HttpGet("getproducttypes")]
        public async Task<IActionResult> GetProductTypes()
        {
            var productTypes = await _repository.GetProductTypesAsync();
            return Ok(productTypes);
        }

        [HttpDelete("deleteproduct/{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var result = await _repository.DeleteProductAsync(id);
            if (!result)
            {
                return NotFound(new { Message = "Product not found" });
            }

            return Ok(new { Message = "Product deleted successfully" });
        }

        [HttpPost("addproduct")]
        public async Task<IActionResult> AddProduct([FromBody] ProductViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var product = new Product
            {
                Name = model.name,
                Price = model.price,
                Description = model.description,
                BrandId = model.brand,
                ProductTypeId = model.producttype
            };

            _repository.Add(product);
            if (await _repository.SaveChangesAsync())
            {
                return Ok(new { Message = $"{model.name} created successfully" });
            }
            return BadRequest("Failed to add product");
        }
    }

}


