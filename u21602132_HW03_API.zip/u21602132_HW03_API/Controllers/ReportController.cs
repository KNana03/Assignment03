﻿using Assignment3_Backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_Backend.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IRepository _repository;

        public ReportController(IRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("generateproductreport")]
        public async Task<IActionResult> GenerateProductReport()
        {
            var report = await _repository.GenerateProductReportAsync();
            return Ok(report);
        }
    }
}
