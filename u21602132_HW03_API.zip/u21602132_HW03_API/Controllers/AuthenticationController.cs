﻿using Assignment3_Backend.Models;
using Assignment3_Backend.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;

        public AuthenticationController(UserManager<AppUser> userManager)
        {
            _userManager = userManager;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserViewModel model)
        {
            var existingUser = await _userManager.FindByEmailAsync(model.emailaddress);
            if (existingUser != null)
            {
                return BadRequest(new { ErrorCode = "DuplicateUserName", Message = "Email is already taken." });
            }

            var user = new AppUser { UserName = model.emailaddress, Email = model.emailaddress };
            var result = await _userManager.CreateAsync(user, model.password);

            if (result.Succeeded)
            {
                return Ok(new { Message = "Registered successfully." });
            }
            return BadRequest(new { Message = "Registration failed.", Errors = result.Errors });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserViewModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.emailaddress);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.password))
            {
                return Ok(new { Message = "Login successful." });
            }
            return Unauthorized();
        }
    }
}