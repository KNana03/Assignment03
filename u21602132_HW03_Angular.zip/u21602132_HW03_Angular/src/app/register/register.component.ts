import { Component } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  alertMessage: string = '';
  showSuccessMessage: boolean = false;

  constructor(private authService: AuthService, private router: Router) { }

  validatePassword(): boolean {
    const passwordRegex = /^(?=.*[0-9])(?=.*[a-zA-Z]).{6,}$/;
    return passwordRegex.test(this.password);
  }

  async register() {
    this.alertMessage = '';
    this.showSuccessMessage = false;

    if (!this.validatePassword()) {
      this.alertMessage = 'Password must be at least 6 characters long and contain at least one number.';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.alertMessage = 'Passwords do not match.';
      return;
    }

    try {
      const user = { emailaddress: this.email, password: this.password };
      const res = await this.authService.register(user).toPromise();
      this.showSuccessMessage = true;
      this.alertMessage = 'Successfully registered';
      setTimeout(() => {
        this.showSuccessMessage = false;
        this.router.navigate(['/login']);
      }, 3000);
    } catch (err: any) {
      if (err.error && err.error.ErrorCode === 'DuplicateUserName') {
        this.alertMessage = 'Email is already taken.';
      } else {
        this.alertMessage = 'Email is already taken.';
      }
    }
  }
}
