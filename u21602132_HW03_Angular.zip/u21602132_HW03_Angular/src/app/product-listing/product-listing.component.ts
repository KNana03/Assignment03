import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-listing',
  templateUrl: './product-listing.component.html',
  styleUrls: ['./product-listing.component.scss']
})
export class ProductListingComponent implements OnInit {
  products: any[] = [];
  filteredProducts: any[] = [];
  filterText: string = '';
  currentPage: number = 1;
  itemsPerPage: number = 5;
  sortColumn: string = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  showDropdown: { [key: string]: boolean } = {
    name: false,
    price: false,
    brand: false,
    productType: false,
    description: false
  };
  constructor(private productService: ProductService, private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.loadProducts();
  }
  toggleDropdown(column: string): void {
    this.showDropdown[column] = !this.showDropdown[column];
  }
  loadProducts(): void {
    this.productService.getProducts().subscribe(
      (res: any) => {
        this.products = res.map((product: any) => {
          const storedProduct = localStorage.getItem(product.name);
          if (storedProduct) {
            const parsedProduct = JSON.parse(storedProduct);
            product.imageUrl = parsedProduct.imageUrl;
          }
          return product;
        });
        this.filteredProducts = this.products;
        console.log('Products loaded:', this.products);
        this.sortProducts();
      },
      err => console.error('Error fetching products:', err)
    );
  }

  filterProducts(): void {
    this.filteredProducts = this.products.filter(product => {
      return product.name.toLowerCase().includes(this.filterText.toLowerCase()) ||
        product.brand.name.toLowerCase().includes(this.filterText.toLowerCase()) ||
        product.productType.name.toLowerCase().includes(this.filterText.toLowerCase()) ||
        product.description.toLowerCase().includes(this.filterText.toLowerCase());
    });
    this.sortProducts();
  }

  onItemsPerPageChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.itemsPerPage = parseInt(value, 10);
  }

  setSortColumn(column: string, event: Event): void {
    const direction = (event.target as HTMLSelectElement).value as 'asc' | 'desc';
    this.sortColumn = column;
    this.sortDirection = direction;
    this.sortProducts();
  }

  sortProducts(): void {
    const compare = (a: any, b: any, column: string) => {
      if (a[column] < b[column]) return this.sortDirection === 'asc' ? -1 : 1;
      if (a[column] > b[column]) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    };

    this.filteredProducts.sort((a, b) => {
      switch (this.sortColumn) {
        case 'name':
          return compare(a, b, 'name');
        case 'price':
          return compare(a, b, 'price');
        case 'brand':
          return compare(a.brand, b.brand, 'name');
        case 'productType':
          return compare(a.productType, b.productType, 'name');
        case 'description':
          return compare(a, b, 'description');
        default:
          return 0;
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
