// loader.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { LoaderService } from './services/loader.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-loader',
  template: `
    <div *ngIf="isLoading" class="loader">
      <div class="loader-content">
        <img src="assets/nikespeedloader.gif" alt="Loading..." class="loader-image" />
        <p style="color: white;">Loading, please wait...</p>
      </div>
    </div>
  `,
  styles: [`
    .loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: #000;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    
    }
    .loader-content {
      text-align: center;
    }
    .loader-image {
      width: 100px;
      height: 100px;
      margin-bottom: 10px;
     
    }
    p {
      margin: 0;
      font-size: 18px;
      color: #333;
    }
  `]
})
export class LoaderComponent implements OnInit, OnDestroy {
  isLoading = false;
  private subscription!: Subscription;

  constructor(private loaderService: LoaderService) { }

  ngOnInit(): void {
    this.subscription = this.loaderService.isLoading.subscribe(
      (isLoading) => {
        this.isLoading = isLoading;
      }
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
