import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  alertMessage: string = '';

  constructor(private authService: AuthService, private router: Router) { }

  async login() {
    this.alertMessage = '';

    try {
      const user = { emailaddress: this.email, password: this.password };
      const res = await this.authService.login(user).toPromise();
      localStorage.setItem('token', res.token);
      this.router.navigate(['/product-listing']);
    } catch (err: any) {
      if (err.status === 401) {
        this.alertMessage = 'Invalid email or password. Please try again.';
      } else {
        this.alertMessage = 'Login failed. Please try again.';
      }
    }
  }
}
