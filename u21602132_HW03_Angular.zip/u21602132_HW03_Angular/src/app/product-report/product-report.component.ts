import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chart } from 'chart.js/auto';
import { environment } from 'src/environments/environment';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-product-report',
  templateUrl: './product-report.component.html',
  styleUrls: ['./product-report.component.scss']
})
export class ProductReportComponent implements OnInit {
  productCountsByBrand: any[] = [];
  productCountsByType: any[] = [];
  activeProductsReport: { [brand: string]: any[] } = {};
  accordionStates: { [key: string]: boolean } = {};

  constructor(private http: HttpClient, private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.fetchProductReport();
  }

  fetchProductReport(): void {
    this.http.get(`${environment.apiUrl}/Report/generateproductreport`).subscribe((report: any) => {
      console.log('Report data:', report);
      this.productCountsByBrand = report.productCountsByBrand;
      this.productCountsByType = report.productCountsByType;
      this.activeProductsReport = report.activeProductsReport.reduce((acc: { [brand: string]: any[] }, curr: any) => {
        if (!acc[curr.brand]) {
          acc[curr.brand] = [];
        }
        acc[curr.brand].push(curr);
        return acc;
      }, {});
      this.createCharts();
    });
  }

  createCharts(): void {
    const brandNames = this.productCountsByBrand.map(item => item.brand);
    const brandCounts = this.productCountsByBrand.map(item => item.count);

    const typeNames = this.productCountsByType.map(item => item.productType);
    const typeCounts = this.productCountsByType.map(item => item.count);

    const brandChartContext = document.getElementById('brandChart') as HTMLCanvasElement;
    new Chart(brandChartContext, {
      type: 'bar',
      data: {
        labels: brandNames,
        datasets: [{
          label: 'Product Count by Brands',
          data: brandCounts,
          backgroundColor: '#90E0EF'
        }]
      },
      options: {
        plugins: {
          title: {
            display: true,
            text: "Item Count By Brands"
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              color: "black",
              z: 1
            }
          }
        }
      }

    });

    const typeChartContext = document.getElementById('typeChart') as HTMLCanvasElement;
    new Chart(typeChartContext, {
      type: 'bar',
      data: {
        labels: typeNames,
        datasets: [{
          label: 'Product Count by Product Types',
          data: typeCounts,
          backgroundColor: '#00B4D8'
        }]
      },

      options: {
        plugins: {
          title: {
            display: true,
            text: "Item Count by Types"
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              color: "black"
            }
          }
        }
      }

    });
  }

  toggleAccordion(brand: string): void {
    this.accordionStates[brand] = !this.accordionStates[brand];
  }

  isAccordionOpen(brand: string): boolean {
    return !!this.accordionStates[brand];
  }

  getObjectKeys(obj: any): string[] {
    return Object.keys(obj);
  }
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
