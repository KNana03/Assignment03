// loader.service.ts
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoaderService {
  isLoading = new Subject<boolean>();
  private hideTimeout: any;

  show() {
    clearTimeout(this.hideTimeout);
    this.isLoading.next(true);
  }

  hide() {
    this.hideTimeout = setTimeout(() => {
      this.isLoading.next(false);
    }, 2500);
  }
}
