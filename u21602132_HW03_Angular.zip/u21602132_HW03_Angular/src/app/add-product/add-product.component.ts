import { Component, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../services/product.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {
  product = {
    name: '',
    price: 0,
    description: '',
    brand: '',
    producttype: '',
    imageUrl: ''
  };
  brands: any[] = [];
  productTypes: any[] = [];
  alertMessage: string = '';
  selectedFile: File | null = null;
  imagePreview: string | ArrayBuffer | null = null;

  constructor(
    private productService: ProductService,
    private authService: AuthService,
    private router: Router,
    private renderer: Renderer2
  ) { }

  ngOnInit(): void {
    this.loadBrands();
    this.loadProductTypes();
  }

  loadBrands(): void {
    this.productService.getBrands().subscribe(
      (res: any) => {
        this.brands = res;
        console.log('Brands loaded:', this.brands);
      },
      err => console.error('Error fetching brands:', err)
    );
  }

  loadProductTypes(): void {
    this.productService.getProductTypes().subscribe(
      (res: any) => {
        this.productTypes = res;
        console.log('Product types loaded:', this.productTypes);
      },
      err => console.error('Error fetching product types:', err)
    );
  }

  onFileSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.imagePreview = e.target.result;
        this.product.imageUrl = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  addProduct(): void {
    if (!this.validateInputs()) {
      return;
    }

    const productData = {
      name: this.product.name,
      price: this.product.price,
      description: this.product.description,
      brand: parseInt(this.product.brand, 10),
      producttype: parseInt(this.product.producttype, 10),
      imageUrl: this.product.imageUrl
    };

    this.productService.addProduct(productData).subscribe(
      res => {
        console.log('Product added successfully');
        this.showSuccessMessage(`${this.product.name} has been created successfully`);
        localStorage.setItem(this.product.name, JSON.stringify(productData));
      },
      err => console.error('Error adding product:', err)
    );
  }

  validateInputs(): boolean {
    this.alertMessage = '';

    if (!this.product.name || !this.product.description || !this.product.brand || !this.product.producttype) {
      this.alertMessage = 'All fields are required.';
      return false;
    }

    if (this.product.price <= 0) {
      this.alertMessage = 'Price must be a positive number.';
      return false;
    }

    if (!this.product.imageUrl) {
      this.alertMessage = 'Product image is required.';
      return false;
    }

    return true;
  }

  showSuccessMessage(message: string): void {
    const messageElement = this.renderer.createElement('div');
    const text = this.renderer.createText(message);
    const closeButton = this.renderer.createElement('button');
    const closeButtonText = this.renderer.createText('x');

    this.renderer.appendChild(closeButton, closeButtonText);
    this.renderer.appendChild(messageElement, text);
    this.renderer.appendChild(messageElement, closeButton);
    this.renderer.addClass(messageElement, 'success-message');
    this.renderer.addClass(closeButton, 'close-button');

    const contentElement = document.querySelector('.content');
    if (contentElement) {
      this.renderer.appendChild(contentElement, messageElement);
    }

    this.renderer.listen(closeButton, 'click', () => {
      if (contentElement) {
        this.renderer.removeChild(contentElement, messageElement);
        this.router.navigate(['/product-listing']);
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
